package br.com.fiap.model.to;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class RecompensaTO {
    private Long id_recompensa;
    @NotBlank private String nm_recompensa;
    @NotBlank private String descricao;
    @NotNull @Positive private int pontos_necessarios;

    public RecompensaTO() {
    }

    public RecompensaTO(Long id_recompensa, String nm_recompensa, String descricao, int pontos_necessarios) {
        this.id_recompensa = id_recompensa;
        this.nm_recompensa = nm_recompensa;
        this.descricao = descricao;
        this.pontos_necessarios = pontos_necessarios;
    }

    public Long getId_recompensa() {
        return id_recompensa;
    }

    public void setId_recompensa(Long id_recompensa) {
        this.id_recompensa = id_recompensa;
    }

    public @NotBlank String getNm_recompensa() {
        return nm_recompensa;
    }

    public void setNm_recompensa(@NotBlank String nm_recompensa) {
        this.nm_recompensa = nm_recompensa;
    }

    public @NotBlank String getDescricao() {
        return descricao;
    }

    public void setDescricao(@NotBlank String descricao) {
        this.descricao = descricao;
    }

    @NotNull
    @Positive
    public int getPontos_necessarios() {
        return pontos_necessarios;
    }

    public void setPontos_necessarios(@NotNull @Positive int pontos_necessarios) {
        this.pontos_necessarios = pontos_necessarios;
    }
}
