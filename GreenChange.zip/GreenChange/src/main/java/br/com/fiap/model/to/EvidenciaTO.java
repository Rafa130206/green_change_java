package br.com.fiap.model.to;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;

import java.time.LocalDate;

public class EvidenciaTO {
    private Long id_evidencia;
    @NotNull private String tipo_evidencia;
    private String url_arquivo;
    @PastOrPresent private LocalDate data_envio;
    @NotNull private String status_evidencia;

    public EvidenciaTO() {
    }

    public EvidenciaTO(Long id_evidencia, String tipo_evidencia, String url_arquivo, LocalDate data_envio, String status_evidencia) {
        this.id_evidencia = id_evidencia;
        this.tipo_evidencia = tipo_evidencia;
        this.url_arquivo = url_arquivo;
        this.data_envio = data_envio;
        this.status_evidencia = status_evidencia;
    }

    public Long getId_evidencia() {
        return id_evidencia;
    }

    public void setId_evidencia(Long id_evidencia) {
        this.id_evidencia = id_evidencia;
    }

    public @NotNull String getTipo_evidencia() {
        return tipo_evidencia;
    }

    public void setTipo_evidencia(@NotNull String tipo_evidencia) {
        this.tipo_evidencia = tipo_evidencia;
    }

    public String getUrl_arquivo() {
        return url_arquivo;
    }

    public void setUrl_arquivo(String url_arquivo) {
        this.url_arquivo = url_arquivo;
    }

    public @PastOrPresent LocalDate getData_envio() {
        return data_envio;
    }

    public void setData_envio(@PastOrPresent LocalDate data_envio) {
        this.data_envio = data_envio;
    }

    public @NotNull String getStatus_evidencia() {
        return status_evidencia;
    }

    public void setStatus_evidencia(@NotNull String status_evidencia) {
        this.status_evidencia = status_evidencia;
    }
}
