package br.com.fiap.model.dao;

import br.com.fiap.model.to.UsuarioTO;

import java.io.Closeable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UsuarioDAO extends Repository {
    public ArrayList<UsuarioTO> findAll() {
        ArrayList<UsuarioTO> usuarios = new ArrayList<UsuarioTO>();
        String sql = "select * from t_gc_usuario order by cpf";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    UsuarioTO usuario = new UsuarioTO();
                    usuario.setCpf(rs.getString("cpf"));
                    usuario.setNome(rs.getString("nome"));
                    usuario.setEmail(rs.getString("email"));
                    usuario.setSenha(rs.getString("senha"));
                    usuario.setCep(rs.getString("cep"));
                    usuario.setForma_pagamento(rs.getString("forma_pagamento"));
                    usuario.setStatus_pagamento(rs.getString("status_pagamento"));
                    usuarios.add(usuario);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro de sql: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return usuarios;
    }

    public UsuarioTO findByCpf (String cpf) {
        UsuarioTO usuario = new UsuarioTO();
        String sql = "SELECT * from t_gc_usuario where cpf = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, cpf);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
                usuario.setCpf(rs.getString("cpf"));
                usuario.setNome(rs.getString("nome"));
                usuario.setEmail(rs.getString("email"));
                usuario.setSenha(rs.getString("senha"));
                usuario.setCep(rs.getString("cep"));
                usuario.setForma_pagamento(rs.getString("forma_pagamento"));
                usuario.setStatus_pagamento(rs.getString("status_pagamento"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return usuario;
    }

    public UsuarioTO save(UsuarioTO usuario) {
        String sql = "insert into t_gc_usuario(cpf,nome,email,senha,cep,forma_pagamento,status_pagamento) values(?,?,?,?,?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, usuario.getCpf());
            ps.setString(2, usuario.getNome());
            ps.setString(3, usuario.getEmail());
            ps.setString(4, usuario.getSenha());
            ps.setString(5, usuario.getCep());
            ps.setString(6, usuario.getForma_pagamento());
            ps.setString(7, usuario.getStatus_pagamento());
            if (ps.executeUpdate() > 0) {
                return usuario;
            }
        } catch (SQLException e) {
            System.out.println("Erro de sql: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete (String cpf) {
        String sql = "delete from t_gc_usuario where cpf = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, cpf);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao excluir: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public UsuarioTO update(UsuarioTO usuario) {
        String sql = "update t_gc_usuario set nome=?, email=?, senha=?, cep=?, forma_pagamento=?, status_pagamento=? where cpf=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)) {
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getSenha());
            ps.setString(4, usuario.getCep());
            ps.setString(5, usuario.getForma_pagamento());
            ps.setString(6, usuario.getStatus_pagamento());
            ps.setString(7, usuario.getCpf());
            if (ps.executeUpdate() > 0) {
                return usuario;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}
