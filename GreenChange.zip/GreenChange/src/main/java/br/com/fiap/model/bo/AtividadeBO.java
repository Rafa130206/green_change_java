package br.com.fiap.model.bo;


import br.com.fiap.model.dao.AtividadeDAO;
import br.com.fiap.model.to.AtividadeTO;

import java.util.ArrayList;

public class AtividadeBO {
    private AtividadeDAO atividadeDAO;
    public ArrayList<AtividadeTO> findAll(){
        atividadeDAO = new AtividadeDAO();
        return atividadeDAO.findAll();
    }

    public AtividadeTO findById(Long id_atividade){
        atividadeDAO = new AtividadeDAO();
        return atividadeDAO.findById(id_atividade);
    }

    public AtividadeTO save(AtividadeTO atividade){
        atividadeDAO = new AtividadeDAO();
        if (atividade.getPontos_recompensa() < 5){
            System.out.println("A recompensa em pontos deve ser um valor maior ou igual a 5");
            return null;
        }
        return atividadeDAO.save(atividade);
    }

    public boolean delete(Long id_atividade) {
        atividadeDAO = new AtividadeDAO();
        return atividadeDAO.delete(id_atividade);
    }

    public AtividadeTO update(AtividadeTO atividade){
        atividadeDAO = new AtividadeDAO();
        return atividadeDAO.update(atividade);
    }
}
