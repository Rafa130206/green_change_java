package br.com.fiap.model.bo;

import br.com.fiap.model.dao.UsuarioDAO;
import br.com.fiap.model.to.UsuarioTO;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UsuarioBO {
    private UsuarioDAO usuarioDAO;
    public ArrayList<UsuarioTO> findAll(){
        usuarioDAO = new UsuarioDAO();
        return usuarioDAO.findAll();
    }

    public UsuarioTO findByCpf (String cpf){
        usuarioDAO = new UsuarioDAO();
        return usuarioDAO.findByCpf(cpf);
    }

    public UsuarioTO save(UsuarioTO usuario) {
        usuarioDAO = new UsuarioDAO();

        String cpfRegex = "^\\d{11}$";
        Pattern cpfPattern = Pattern.compile(cpfRegex);
        Matcher cpfMatcher = cpfPattern.matcher(usuario.getCpf());
        if (!cpfMatcher.matches()) {
            System.out.println("O CPF deve conter exatamente 11 números.");
            return null;
        }

        String emailRegex = "^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$";
        Pattern emailPattern = Pattern.compile(emailRegex);
        Matcher emailMatcher= emailPattern.matcher(usuario.getEmail());
        if (!emailMatcher.matches()) {
            System.out.println("Email inválido!");
            return null;
        }

        if (usuario.getSenha() == null || usuario.getSenha().length() < 8) {
            System.out.println("A senha deve ter pelo menos 8 dígitos!");
            return null;
        }

        if (usuario.getCep() == null || usuario.getCep().length() != 8) {
            System.out.println("O CEP deve ser formado por 8 dígitos!");
            return null;
        }

        return usuarioDAO.save(usuario);
    }

    public boolean delete(String cpf) {
        usuarioDAO = new UsuarioDAO();
        return usuarioDAO.delete(cpf);
    }

    public UsuarioTO update(UsuarioTO usuario) {
        usuarioDAO = new UsuarioDAO();

        String cpfRegex = "^\\d{11}$";
        Pattern cpfPattern = Pattern.compile(cpfRegex);
        Matcher cpfMatcher = cpfPattern.matcher(usuario.getCpf());
        if (!cpfMatcher.matches()) {
            System.out.println("O CPF deve conter exatamente 11 números.");
            return null;
        }

        String emailRegex = "^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$";
        Pattern emailPattern = Pattern.compile(emailRegex);
        Matcher emailMatcher= emailPattern.matcher(usuario.getEmail());
        if (!emailMatcher.matches()) {
            System.out.println("Email inválido!");
            return null;
        }

        if (usuario.getSenha() == null || usuario.getSenha().length() < 8) {
            System.out.println("A senha deve ter pelo menos 8 dígitos!");
            return null;
        }

        if (usuario.getCep() == null || usuario.getCep().length() != 8) {
            System.out.println("O CEP deve ser formado por 8 dígitos!");
            return null;
        }

        return usuarioDAO.update(usuario);
    }
}
