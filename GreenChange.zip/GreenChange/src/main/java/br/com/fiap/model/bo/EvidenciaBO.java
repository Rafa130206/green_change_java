package br.com.fiap.model.bo;

import br.com.fiap.model.dao.EvidenciaDAO;
import br.com.fiap.model.to.EvidenciaTO;

import java.time.LocalDate;
import java.util.ArrayList;

public class EvidenciaBO {
    private EvidenciaDAO evidenciaDAO;
    public ArrayList<EvidenciaTO> findAll(){
        evidenciaDAO = new EvidenciaDAO();
        return evidenciaDAO.findAll();
    }

    public EvidenciaTO findById(Long id_evidencia){
        evidenciaDAO = new EvidenciaDAO();
        return evidenciaDAO.findById(id_evidencia);
    }

    public EvidenciaTO save(EvidenciaTO evidencia){
        evidenciaDAO = new EvidenciaDAO();
        if (!evidencia.getData_envio().isBefore(LocalDate.now())){
            System.out.println("A data de envio não pode ser anterior ao dia de hoje");
            return null;
        }
        return evidenciaDAO.save(evidencia);
    }

    public boolean delete(Long id_evidencia) {
        evidenciaDAO = new EvidenciaDAO();
        return evidenciaDAO.delete(id_evidencia);
    }

    public EvidenciaTO update(EvidenciaTO evidencia){
        evidenciaDAO = new EvidenciaDAO();
        return evidenciaDAO.update(evidencia);
    }
}
