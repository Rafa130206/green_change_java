package br.com.fiap.model.to;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class AtividadeTO {
    private Long id_atividade;
    @NotBlank private String descricao;
    @NotNull @Positive private int pontos_recompensa;

    public AtividadeTO() {
    }

    public AtividadeTO(Long id_atividade, String descricao, int pontos_recompensa) {
        this.id_atividade = id_atividade;
        this.descricao = descricao;
        this.pontos_recompensa = pontos_recompensa;
    }

    public Long getId_atividade() {
        return id_atividade;
    }

    public void setId_atividade(Long id_atividade) {
        this.id_atividade = id_atividade;
    }

    public @NotBlank String getDescricao() {
        return descricao;
    }

    public void setDescricao(@NotBlank String descricao) {
        this.descricao = descricao;
    }

    @NotNull
    @Positive
    public int getPontos_recompensa() {
        return pontos_recompensa;
    }

    public void setPontos_recompensa(@NotNull @Positive int pontos_recompensa) {
        this.pontos_recompensa = pontos_recompensa;
    }
}
