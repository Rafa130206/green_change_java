package br.com.fiap.model.bo;

import br.com.fiap.model.dao.RecompensaDAO;
import br.com.fiap.model.to.RecompensaTO;

import java.util.ArrayList;

public class RecompensaBO {
    private RecompensaDAO recompensaDAO;
    public ArrayList<RecompensaTO> findAll(){
        recompensaDAO = new RecompensaDAO();
        return recompensaDAO.findAll();
    }

    public RecompensaTO findById(Long id_recompensa){
        recompensaDAO = new RecompensaDAO();
        return recompensaDAO.findById(id_recompensa);
    }

    public RecompensaTO save(RecompensaTO recompensa){
        recompensaDAO = new RecompensaDAO();
        if (recompensa.getPontos_necessarios() < 5){
            System.out.println("A recompensa em pontos deve ser um valor maior ou igual a 5");
            return null;
        }
        return recompensaDAO.save(recompensa);
    }

    public boolean delete(Long id_recompensa) {
        recompensaDAO = new RecompensaDAO();
        return recompensaDAO.delete(id_recompensa);
    }

    public RecompensaTO update(RecompensaTO recompensa){
        recompensaDAO = new RecompensaDAO();
        if (recompensa.getPontos_necessarios() < 5){
            System.out.println("A recompensa em pontos deve ser um valor maior ou igual a 5");
            return null;
        }
        return recompensaDAO.update(recompensa);
    }
}
