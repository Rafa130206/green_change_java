package br.com.fiap.model.dao;

import br.com.fiap.model.to.RecompensaTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Period;
import java.util.ArrayList;

public class RecompensaDAO extends Repository {
    public ArrayList<RecompensaTO> findAll(){
        ArrayList<RecompensaTO> recompensas = new ArrayList<RecompensaTO>();
        String sql = "select * from t_gc_recompensa order by id_recompensa";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ResultSet rs = ps.executeQuery();
            if (rs != null){
                while (rs.next()){
                    RecompensaTO recompensa = new RecompensaTO();
                    recompensa.setId_recompensa(rs.getLong("id_recompensa"));
                    recompensa.setNm_recompensa(rs.getString("nm_recompensa"));
                    recompensa.setDescricao(rs.getString("descricao"));
                    recompensa.setPontos_necessarios(rs.getInt("pontos_necessarios"));
                    recompensas.add(recompensa);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro de sql: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return recompensas;
    }

    public RecompensaTO findById (Long id_recompensa){
        RecompensaTO recompensa = new RecompensaTO();
        String sql = "SELECT * from t_gc_recompensa where id_recompensa=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, id_recompensa);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
                recompensa.setId_recompensa(rs.getLong("id_recompensa"));
                recompensa.setNm_recompensa(rs.getString("nm_recompensa"));
                recompensa.setDescricao(rs.getString("descricao"));
                recompensa.setPontos_necessarios(rs.getInt("pontos_necessarios"));
            } else {
                return null;
            }
        } catch (SQLException e){
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return recompensa;
    }

    public RecompensaTO save(RecompensaTO recompensa){
        String sql = "insert into t_gc_recompensa(nm_recompensa,descricao,pontos_necessarios) values(?,?,?)";
        try(PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, recompensa.getNm_recompensa());
            ps.setString(2, recompensa.getDescricao());
            ps.setInt(3, recompensa.getPontos_necessarios());
            if (ps.executeUpdate() > 0){
                return recompensa;
            }
        } catch (SQLException e){
            System.out.println("Erro de sql: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long id_recompensa){
        String sql = "delete from t_gc_recompensa where id_recompensa=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, id_recompensa);
            return ps.executeUpdate() > 0;
        } catch (SQLException e){
            System.out.println("Erro ao excluir: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public RecompensaTO update(RecompensaTO recompensa){
        String sql = "update t_gc_recompensa set nm_recompensa=?, descricao=?, pontos_necessarios=? where id_recompensa=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, recompensa.getNm_recompensa());
            ps.setString(2, recompensa.getDescricao());
            ps.setInt(3, recompensa.getPontos_necessarios());
            ps.setLong(4, recompensa.getId_recompensa());
            if (ps.executeUpdate() > 0){
                return recompensa;
            } else {
                return null;
            }
        } catch (SQLException e){
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}
