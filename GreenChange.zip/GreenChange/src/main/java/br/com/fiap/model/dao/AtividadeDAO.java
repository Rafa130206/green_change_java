package br.com.fiap.model.dao;

import br.com.fiap.model.to.AtividadeTO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AtividadeDAO extends Repository {
    public ArrayList<AtividadeTO> findAll() {
        ArrayList<AtividadeTO> atividades = new ArrayList<AtividadeTO>();
        String sql = "select * from t_gc_atividade order by id_atividade";
        try(PreparedStatement ps = getConnection().prepareStatement(sql)){
            ResultSet rs = ps.executeQuery();
            if (rs != null){
                while (rs.next()){
                    AtividadeTO atividade = new AtividadeTO();
                    atividade.setId_atividade(rs.getLong("id_atividade"));
                    atividade.setDescricao(rs.getString("descricao"));
                    atividade.setPontos_recompensa(rs.getInt("pontos_recompensa"));
                    atividades.add(atividade);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro de sql: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return atividades;
    }

    public AtividadeTO findById (Long id_atividade){
        AtividadeTO atividade = new AtividadeTO();
        String sql = "SELECT * from t_gc_atividade where id_atividade = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, id_atividade);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
                atividade.setId_atividade(rs.getLong("id_atividade"));
                atividade.setDescricao(rs.getString("descricao"));
                atividade.setPontos_recompensa(rs.getInt("pontos_recompensa"));
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro na consulta: " + e.getMessage());
        }finally {
            closeConnection();
        }
        return atividade;
    }

    public AtividadeTO save(AtividadeTO atividade){
        String sql = "insert into t_gc_atividade(descricao,pontos_recompensa) values (?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, atividade.getDescricao());
            ps.setInt(2, atividade.getPontos_recompensa());
            if (ps.executeUpdate() > 0){
                return atividade;
            }
        } catch (SQLException e){
            System.out.println("Erro de sql: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long id_atividade) {
        String sql = "delete from t_gc_atividade where id_atividade = ?";
        try(PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, id_atividade);
            return ps.executeUpdate() > 0;
        } catch (SQLException e){
            System.out.println("Erro ao exlcuir: " + e.getMessage());
        }finally {
            closeConnection();
        }
        return false;
    }

    public AtividadeTO update(AtividadeTO atividade){
        String sql = "update t_gc_atividade set descricao=?, pontos_recompensa=? where id_atividade=?";
        try(PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, atividade.getDescricao());
            ps.setInt(2, atividade.getPontos_recompensa());
            ps.setLong(3, atividade.getId_atividade());
            if (ps.executeUpdate() > 0){
                return atividade;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}
