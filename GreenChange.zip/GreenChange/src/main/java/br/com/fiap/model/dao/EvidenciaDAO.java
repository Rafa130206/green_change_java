package br.com.fiap.model.dao;

import br.com.fiap.model.to.EvidenciaTO;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EvidenciaDAO extends Repository {
    public ArrayList<EvidenciaTO> findAll(){
        ArrayList<EvidenciaTO> evidencias = new ArrayList<EvidenciaTO>();
        String sql = "select * from t_gc_evidencia order by id_evidencia";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ResultSet rs = ps.executeQuery();
            if (rs != null) {
                while (rs.next()){
                    EvidenciaTO evidencia = new EvidenciaTO();
                    evidencia.setId_evidencia(rs.getLong("id_evidencia"));
                    evidencia.setTipo_evidencia(rs.getString("tipo_evidencia"));
                    evidencia.setUrl_arquivo(rs.getString("url_arquivo"));
                    evidencia.setData_envio(rs.getDate("data_envio").toLocalDate());
                    evidencia.setStatus_evidencia(rs.getString("status_evidencia"));
                    evidencias.add(evidencia);
                }
            }
        } catch (SQLException e){
            System.out.println("Erro de sql: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return evidencias;
    }

    public EvidenciaTO findById (Long id_evidencia){
        EvidenciaTO evidencia = new EvidenciaTO();
        String sql = "SELECT * from t_gc_evidencia where id_evidencia = ?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, id_evidencia);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){
                evidencia.setId_evidencia(rs.getLong("id_evidencia"));
                evidencia.setTipo_evidencia(rs.getString("tipo_evidencia"));
                evidencia.setUrl_arquivo(rs.getString("url_arquivo"));
                evidencia.setData_envio(rs.getDate("data_envio").toLocalDate());
                evidencia.setStatus_evidencia(rs.getString("status_evidencia"));
            } else {
                return null;
            }
        } catch (SQLException e){
            System.out.println("Erro na consulta: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return evidencia;
    }

    public EvidenciaTO save(EvidenciaTO evidencia){
        String sql = "insert into t_gc_evidencia(tipo_evidencia,url_arquivo,data_envio,status_evidencia) values (?,?,?,?)";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, evidencia.getTipo_evidencia());
            ps.setString(2, evidencia.getUrl_arquivo());
            ps.setDate(3, Date.valueOf(evidencia.getData_envio()));
            ps.setString(4, evidencia.getStatus_evidencia());
            if (ps.executeUpdate() > 0){
                return evidencia;
            }
        } catch (SQLException e){
            System.out.println("Erro de sql: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }

    public boolean delete(Long id_evidencia) {
        String sql = "delete from t_gc_evidencia where id_evidencia=?";
        try (PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setLong(1, id_evidencia);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Erro ao exlcuir: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return false;
    }

    public EvidenciaTO update(EvidenciaTO evidencia) {
        String sql = "update t_gc_evidencia set tipo_evidencia=?, url_arquivo=?, data_envio=?, status_evidencia=? where id_evidencia=?";
        try(PreparedStatement ps = getConnection().prepareStatement(sql)){
            ps.setString(1, evidencia.getTipo_evidencia());
            ps.setString(2, evidencia.getUrl_arquivo());
            ps.setDate(3, Date.valueOf(evidencia.getData_envio()));
            ps.setString(4, evidencia.getStatus_evidencia());
            ps.setLong(5, evidencia.getId_evidencia());
            if (ps.executeUpdate() > 0){
                return evidencia;
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar: " + e.getMessage());
        } finally {
            closeConnection();
        }
        return null;
    }
}
