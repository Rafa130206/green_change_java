package br.com.fiap.resource;

import br.com.fiap.model.bo.AtividadeBO;
import br.com.fiap.model.to.AtividadeTO;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.ArrayList;

@Path("/atividade")
public class AtividadeResource {
    private AtividadeBO atividadeBO = new AtividadeBO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response findAll(){
        ArrayList<AtividadeTO> resultado = atividadeBO.findAll();
        Response.ResponseBuilder response = null;
        if (resultado == null || resultado.isEmpty()) {
            return Response.status(404).entity("Nenhum usuário encontrado").build();
        } else {
            return Response.ok(resultado).build();
        }
    }

    @GET
    @Path("/{id_atividade}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findById(@PathParam("id_atividade") Long id_atividade){
        AtividadeTO resultado = atividadeBO.findById(id_atividade);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.ok();
        } else {
            response = Response.status(404);
        }
        response.entity(resultado);
        return response.build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response save(@Valid AtividadeTO atividade) {
        AtividadeTO resultado = atividadeBO.save(atividade);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.created(null);
        }else {
            response = Response.status(400);
        }
        response.entity(resultado);
        return response.build();
    }

    @DELETE
    @Path("/{id_atividade}")
    public Response delete(@PathParam("id_atividade") Long id_atividade) {
        Response.ResponseBuilder response = null;
        if(atividadeBO.delete(id_atividade)) {
            response = Response.status(204);
        } else {
            response.status(404);
        }
        return response.build();
    }

    @PUT
    @Path("/{id_atividade}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response update(@Valid AtividadeTO atividade, @PathParam("id_atividade") Long id_atividade) {
        atividade.setId_atividade(id_atividade);
        AtividadeTO resultado = atividadeBO.update(atividade);
        Response.ResponseBuilder response = null;
        if (resultado != null) {
            response = Response.created(null);  // 201 CREATED
        } else {
            response = Response.status(400);  // 400 BAD REQUEST
        }
        response.entity(resultado);
        return response.build();
    }
}
