package br.com.fiap.model.to;

import jakarta.validation.constraints.NotBlank;

public class UsuarioTO {
    @NotBlank private String cpf;
    @NotBlank private String nome;
    @NotBlank private String email;
    @NotBlank private String senha;
    @NotBlank private String cep;
    @NotBlank private String forma_pagamento;
    @NotBlank private String status_pagamento;

    public UsuarioTO() {
    }

    public UsuarioTO(String cpf, String nome, String email, String senha, String cep, String forma_pagamento, String status_pagamento) {
        this.cpf = cpf;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.cep = cep;
        this.forma_pagamento = forma_pagamento;
        this.status_pagamento = status_pagamento;
    }

    public @NotBlank String getCpf() {
        return cpf;
    }

    public void setCpf(@NotBlank String cpf) {
        this.cpf = cpf;
    }

    public @NotBlank String getNome() {
        return nome;
    }

    public void setNome(@NotBlank String nome) {
        this.nome = nome;
    }

    public @NotBlank String getEmail() {
        return email;
    }

    public void setEmail(@NotBlank String email) {
        this.email = email;
    }

    public @NotBlank String getSenha() {
        return senha;
    }

    public void setSenha(@NotBlank String senha) {
        this.senha = senha;
    }

    public @NotBlank String getCep() {
        return cep;
    }

    public void setCep(@NotBlank String cep) {
        this.cep = cep;
    }

    public @NotBlank String getForma_pagamento() {
        return forma_pagamento;
    }

    public void setForma_pagamento(@NotBlank String forma_pagamento) {
        this.forma_pagamento = forma_pagamento;
    }

    public String getStatus_pagamento() {
        return status_pagamento;
    }

    public void setStatus_pagamento(String status_pagamento) {
        this.status_pagamento = status_pagamento;
    }
}
